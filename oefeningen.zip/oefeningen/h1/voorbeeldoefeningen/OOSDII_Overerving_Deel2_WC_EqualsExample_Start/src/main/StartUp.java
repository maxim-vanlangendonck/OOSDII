
package main;

import ui.EqualsApp;

public class StartUp {
    public static void main(String[] args) {
        new EqualsApp();
    }
}
